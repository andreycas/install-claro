Verwenden Sie f�r die Entschl�sselung der Datei Proxy.jar.ucc das Programm UCYBCRYP.EXE, welches sich auf dem Automation Engine Image im Ordner IMAGE:\TOOLS\ENCRYPT befindet. Rufen Sie nun das Programm �ber die Kommandozeile mit folgenden Parametern auf: 

UCYBCRYP.EXE -d -f Proxy.jar.ucc -l Lizenzdatei

Die Lizenzdatei wurde Ihnen vom Support geliefert (Kundennummer.TXT).
  
Als Ergebnis erhalten Sie eine Datei namens Proxy.jar.

