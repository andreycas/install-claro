Use the program UCYBCRYP.EXE to decrypt the file Proxy.jar.ucc. It is found in the folder IMAGE:\TOOLS\ENCRYPT on the Automation Engine Image. Now call the program through the command line with the following parameters: 

UCYBCRYP.EXE -d -f Proxy.jar.ucc -l License file

The license file was supplied by our support team (customer number.TXT).
  
The result is the packed file Proxy.jar. 
